package com.zxz.launcher.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Reads launchable apps through PackageManager. No background work; callers decide when to refresh. */
class AppRepository(private val context: Context) {

    private val iconPx: Int = (context.resources.displayMetrics.density * ICON_DP).toInt()

    suspend fun loadApps(): List<AppInfo> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        queryActivities(pm, query)
            .filter { it.activityInfo.packageName != context.packageName }
            .map { info ->
                AppInfo(
                    label = info.loadLabel(pm).toString(),
                    packageName = info.activityInfo.packageName,
                    className = info.activityInfo.name,
                    icon = info.loadIcon(pm).toBitmap(iconPx, iconPx).asImageBitmap(),
                )
            }
            .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.label })
    }

    /** Default dock: the user's default dialer, messaging, browser and camera apps, topped up from the app list. */
    fun defaultDock(apps: List<AppInfo>): List<AppInfo> {
        val pm = context.packageManager
        val dockIntents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")).addCategory(Intent.CATEGORY_BROWSABLE),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE),
        )
        val dock = mutableListOf<AppInfo>()
        for (intent in dockIntents) {
            val pkg = resolvePackage(pm, intent) ?: continue
            val match = apps.firstOrNull { it.packageName == pkg && it !in dock }
            if (match != null) dock += match
        }
        for (app in apps) {
            if (dock.size >= DOCK_SIZE) break
            if (app !in dock) dock += app
        }
        return dock.take(DOCK_SIZE)
    }

    private fun queryActivities(pm: PackageManager, intent: Intent): List<ResolveInfo> =
        if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }

    private fun resolvePackage(pm: PackageManager, intent: Intent): String? {
        val info = if (Build.VERSION.SDK_INT >= 33) {
            pm.resolveActivity(intent, PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_DEFAULT_ONLY.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        }
        return info?.activityInfo?.packageName
    }

    private companion object {
        const val ICON_DP = 56
        const val DOCK_SIZE = 4
    }
}
