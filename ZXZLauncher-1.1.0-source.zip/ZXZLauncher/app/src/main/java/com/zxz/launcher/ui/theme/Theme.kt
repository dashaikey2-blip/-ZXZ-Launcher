package com.zxz.launcher.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp

/** Shared design tokens for the glass look. */
object Zxz {
    val glassFill = Color.White.copy(alpha = 0.18f)
    val glassStroke = Color.White.copy(alpha = 0.25f)
    val dockShape = RoundedCornerShape(30.dp)
    val textShadow = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.45f), blurRadius = 6f))
    val wallpaperScrim = Brush.verticalGradient(
        listOf(Color(0x33000000), Color.Transparent, Color(0x55000000))
    )
}

@Composable
fun ZxzTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(), content = content)
}
