package com.zxz.launcher.ui.home

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.geometry.Offset

/** Lightweight depth/parallax wallpaper treatment; drag gently to move the layered light fields. */
@Composable
fun SpatialWallpaper(content: @Composable () -> Unit) {
    var shiftX by remember { mutableFloatStateOf(0f) }
    var shiftY by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectDragGestures { change, drag ->
                    change.consume()
                    shiftX = (shiftX + drag.x * 0.10f).coerceIn(-34f, 34f)
                    shiftY = (shiftY + drag.y * 0.10f).coerceIn(-34f, 34f)
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(brush = Brush.linearGradient(listOf(Color(0xFF101827), Color(0xFF263B50), Color(0xFF080D17))))
            drawCircle(
                brush = Brush.radialGradient(listOf(Color(0xAA55A6D8), Color.Transparent), center = Offset(size.width * 0.78f + shiftX, size.height * 0.22f + shiftY), radius = size.minDimension * 0.72f),
                radius = size.minDimension * 0.72f,
                center = Offset(size.width * 0.78f + shiftX, size.height * 0.22f + shiftY)
            )
            drawCircle(
                brush = Brush.radialGradient(listOf(Color(0x995C4C9A), Color.Transparent), center = Offset(size.width * 0.10f - shiftX * 0.65f, size.height * 0.72f - shiftY * 0.65f), radius = size.minDimension * 0.66f),
                radius = size.minDimension * 0.66f,
                center = Offset(size.width * 0.10f - shiftX * 0.65f, size.height * 0.72f - shiftY * 0.65f)
            )
        }
        content()
    }
}
