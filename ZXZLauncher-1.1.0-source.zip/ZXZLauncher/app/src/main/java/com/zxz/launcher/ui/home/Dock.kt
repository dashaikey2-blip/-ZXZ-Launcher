package com.zxz.launcher.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.zxz.launcher.data.AppInfo
import com.zxz.launcher.ui.theme.Zxz

@Composable
fun Dock(apps: List<AppInfo>, onLaunch: (AppInfo) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(Zxz.dockShape)
            .background(Zxz.glassFill)
            .border(1.dp, Zxz.glassStroke, Zxz.dockShape)
            .padding(vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
    ) {
        apps.forEach { AppIcon(app = it, onClick = onLaunch, showLabel = false) }
    }
}
