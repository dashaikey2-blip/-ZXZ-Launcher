package com.zxz.launcher.data

import androidx.compose.ui.graphics.ImageBitmap

data class AppInfo(
    val label: String,
    val packageName: String,
    val className: String,
    val icon: ImageBitmap,
) {
    val key: String get() = "$packageName/$className"
}
