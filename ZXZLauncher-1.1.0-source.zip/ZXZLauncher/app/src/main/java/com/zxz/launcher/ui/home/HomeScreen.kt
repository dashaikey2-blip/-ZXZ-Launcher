package com.zxz.launcher.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.material3.Text
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zxz.launcher.data.AppInfo

/** ZXZ home: spatial wallpaper, smart capsule, liquid-glass clock, app grid and dock. */
@Composable
fun HomeScreen(viewModel: HomeViewModel, onLaunch: (AppInfo) -> Unit) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    SpatialWallpaper {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)) {
            Box(Modifier.fillMaxWidth().padding(top = 12.dp), contentAlignment = Alignment.Center) {
                SmartCapsule()
            }
            Text(
                text = "Hello",
                color = Color.White,
                fontSize = 34.sp,
                fontWeight = FontWeight.Light,
                letterSpacing = (-1.2).sp,
                modifier = Modifier.padding(start = 26.dp, top = 20.dp, bottom = 2.dp)
            )
            ClockWidget(Modifier.fillMaxWidth().padding(top = 8.dp, start = 20.dp, end = 20.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(state.apps, key = { it.key }) { app -> AppIcon(app = app, onClick = onLaunch) }
            }
            Dock(
                apps = state.dock,
                onLaunch = onLaunch,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            )
        }
    }
}
