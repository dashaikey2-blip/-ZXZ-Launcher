# ZXZ Launcher 1.1.0 — visual feature update

Kotlin + Jetpack Compose launcher for Android 10+ (minSdk 29), targeting Android 13 (targetSdk 33). Developer: ZXZ.

## Added in 1.1.0
- **Liquid Glass clock card:** translucent layered surface, fine border and premium clock typography. This is a lightweight glass treatment rather than a system-wide blur effect.
- **Smart Capsule:** compact pill showing ZXZ, A51 and the device's live battery percentage from Android's battery broadcast.
- **Spatial wallpaper effect:** layered radial light fields with drag-based parallax for a subtle depth illusion. This is a launcher wallpaper effect, not a true iOS depth wallpaper or lock-screen replacement.
- **Hello greeting:** minimal iOS-inspired typography above the clock.

## Existing foundation
- HOME / DEFAULT launcher activity
- Installed app list via PackageManager
- App list refresh on install/uninstall while launcher is visible
- Glass dock and app launch handling

## Build status
Source update prepared but **not compiled or device-tested in this environment**. The original environment did not include Android SDK/build-tools and had no network access.

## Build with GitHub Actions
1. Push this folder to a GitHub repository on branch `main`.
2. Open the repository's **Actions** tab.
3. Run **Build ZXZ Launcher APK** (or push a commit).
4. Download the `ZXZLauncher-1.1.0` artifact from the workflow run.

The workflow uses Gradle 8.7 and JDK 17.

## Install on Samsung Galaxy A51
Copy the generated APK to the phone, allow installation from the chosen file manager, install, press Home and select ZXZ Launcher.

To return to One UI Home: Settings → Apps → Choose default apps → Home app.

Note: release APK signing currently uses the debug signing config for personal testing. Do not use that key for Play Store publishing.
